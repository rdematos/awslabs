var aws = require('aws-sdk');

/*
// Enable AWS SDK for JavaScript support using a service model file
var myService = new AWS.Service({apiConfig: require('./path/to/service-model.json'), endpoint: "service enpoint"});

// Look up operation names and parameters in the model file under 'shapes'. Use camel case.
myService.someOperation(params, function(err, data) {
    console.log(err, data);
});
*/

var iot = new aws.Service({apiConfig: require('./iot-service-model.json'), endpoint: "t71u6yob51.execute-api.us-east-1.amazonaws.com/beta" });
var iotData = new aws.Service({apiConfig: require('./iot-data-service-model.json'), endpoint: "g-ws.us-east-1.pb.iot.amazonaws.com" });


exports.handler = function(event, context) {

    // Exercising an IoT Data operation as an example
    var params = {
        "topic" : "foo/bar",
        "payload" : "hello world"
    };

    iotData.publish(params, function(err, data) {
        console.log(err, data);
        context.done();
    });
    
};
