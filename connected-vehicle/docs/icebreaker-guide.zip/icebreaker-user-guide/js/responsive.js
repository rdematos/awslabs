
$(document).ready(function () {

    // on click of the ellipsis (#toggle-contents), toggle the left ToC display from 'none' to 'block'
    $( '#toggle-contents' ).click(function() {
        $( '#toc' ).toggleClass( "open" );
    });

});


