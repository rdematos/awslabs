/**
 * Created by huntsper on 4/10/15.
 */



/*$('#pdf-and-forum-show').click(function(){
    $('#pdf-and-forum').toggleClass('visible');
    $('#pdf-and-forum-show').toggleClass("fa-caret-square-o-up fa-caret-square-o-down");
});*/

$('#feedback-show').click(function(){
    $('#feedback').toggleClass('visible');
});

$('#toggle-contents').click(function(){
    $('#toc').toggleClass('visible');
});
